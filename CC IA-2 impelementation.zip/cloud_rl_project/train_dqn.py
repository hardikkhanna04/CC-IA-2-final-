import matplotlib.pyplot as plt
from env_cloud import CloudEnv
from dqn_agent import DQNAgent
from replay_buffer import ReplayBuffer

env = CloudEnv()
state_dim = env.observation_space.shape[0]
action_dim = env.action_space.n

agent = DQNAgent(state_dim, action_dim)
replay_buffer = ReplayBuffer()
num_episodes = 300
batch_size = 64
epsilon = 1.0
epsilon_decay = 0.985
min_epsilon = 0.1
rewards = []

for episode in range(num_episodes):
    state = env.reset()
    total_reward = 0
    done = False

    while not done:
        action = agent.select_action(state, epsilon)
        next_state, reward, done, _ = env.step(action)
        replay_buffer.push(state, action, reward, next_state, done)
        state = next_state
        total_reward += reward

        agent.train(replay_buffer, batch_size)

    epsilon = max(min_epsilon, epsilon * epsilon_decay)
    rewards.append(total_reward)
    agent.update_target()

    if episode % 10 == 0:
        print(f"Episode {episode}/{num_episodes} | Total Reward: {total_reward:.2f} | Epsilon: {epsilon:.2f}")

# Plot
plt.plot(rewards)
plt.xlabel("Episode")
plt.ylabel("Total Reward")
plt.title("DQN Training Reward per Episode")
plt.show()
