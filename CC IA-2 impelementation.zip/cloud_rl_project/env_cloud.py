import gym
from gym import spaces
import numpy as np

class CloudEnv(gym.Env):
    def __init__(self):
        super(CloudEnv, self).__init__()
        self.max_instances = 10
        self.min_instances = 1
        self.current_instances = 5
        self.cpu_load = 50  # in percent
        self.time = 0

        # Action space: -1 (scale down), 0 (no change), 1 (scale up)
        self.action_space = spaces.Discrete(3)

        # Observation space: [current_instances, cpu_load]
        self.observation_space = spaces.Box(
            low=np.array([self.min_instances, 0]),
            high=np.array([self.max_instances, 100]),
            dtype=np.float32
        )

    def reset(self):
        self.current_instances = 5
        self.cpu_load = np.random.uniform(30, 70)
        self.time = 0
        return self._get_obs()

    def _get_obs(self):
        return np.array([self.current_instances, self.cpu_load], dtype=np.float32)

    def step(self, action):
        if action == 0:
            delta = 0
        elif action == 1:
            delta = 1
        elif action == 2:
            delta = -1

        self.current_instances = np.clip(
            self.current_instances + delta,
            self.min_instances,
            self.max_instances
        )

        # Simulate CPU load changes
        self.cpu_load = np.clip(
            self.cpu_load + np.random.randn() * 5 - delta * 3,
            0, 100
        )

        # Reward: penalize high CPU load or too many instances
        over_utilized_penalty = max(0, self.cpu_load - 75)
        under_utilized_penalty = max(0, 30 - self.cpu_load)
        cost_penalty = self.current_instances * 2
        reward = 500 - (over_utilized_penalty + under_utilized_penalty + cost_penalty)

        self.time += 1
        done = self.time >= 100

        return self._get_obs(), reward, done, {}

    def render(self, mode="human"):
        print(f"Instances: {self.current_instances} | Load: {self.cpu_load:.2f}")
